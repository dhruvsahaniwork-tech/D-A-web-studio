﻿/**
 * D&A Web Studio - Three.js Interactive 3D Background & Hero Experience
 * High-performance 3D particle constellation & geometric floating core.
 */

(function () {
  let scene, camera, renderer;
  let particleSystem, geometryMesh, innerCore, ringMesh;
  let mouseX = 0, mouseY = 0;
  let targetX = 0, targetY = 0;
  let windowHalfX = window.innerWidth / 2;
  let windowHalfY = window.innerHeight / 2;
  let scrollY = 0;
  let isVisible = true;

  function initThree() {
    const canvas = document.getElementById("webgl-canvas");
    if (!canvas || typeof THREE === "undefined") return;

    // 1. Scene
    scene = new THREE.Scene();
    scene.fog = new THREE.FogExp2(0x0a0f0d, 0.0015);

    // 2. Camera
    camera = new THREE.PerspectiveCamera(
      60,
      window.innerWidth / window.innerHeight,
      1,
      2000
    );
    camera.position.z = 600;

    // 3. Renderer
    renderer = new THREE.WebGLRenderer({
      canvas: canvas,
      alpha: true,
      antialias: true,
      powerPreference: "high-performance"
    });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.setSize(window.innerWidth, window.innerHeight);

    // 4. Create 3D Particle Cloud
    const particleCount = 1200;
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(particleCount * 3);
    const colors = new Float32Array(particleCount * 3);

    // Brand Palette colors: Sage (#93ab88), Emerald (#10b981), Cyan (#38bdf8), White
    const colorChoices = [
      new THREE.Color(0x93ab88),
      new THREE.Color(0x10b981),
      new THREE.Color(0x38bdf8),
      new THREE.Color(0xecfdf5),
      new THREE.Color(0xa7f3d0)
    ];

    for (let i = 0; i < particleCount * 3; i += 3) {
      // Spread in 3D sphere/cylinder
      const radius = 400 + Math.random() * 600;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.acos(2 * Math.random() - 1);

      positions[i] = radius * Math.sin(phi) * Math.cos(theta);
      positions[i + 1] = radius * Math.sin(phi) * Math.sin(theta);
      positions[i + 2] = radius * Math.cos(phi);

      const color = colorChoices[Math.floor(Math.random() * colorChoices.length)];
      colors[i] = color.r;
      colors[i + 1] = color.g;
      colors[i + 2] = color.b;
    }

    geometry.setAttribute("position", new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute("color", new THREE.BufferAttribute(colors, 3));

    // Particle texture generator
    const canvasTexture = document.createElement("canvas");
    canvasTexture.width = 32;
    canvasTexture.height = 32;
    const ctx = canvasTexture.getContext("2d");
    const gradient = ctx.createRadialGradient(16, 16, 0, 16, 16, 16);
    gradient.addColorStop(0, "rgba(255,255,255,1)");
    gradient.addColorStop(0.3, "rgba(147,171,136,0.8)");
    gradient.addColorStop(0.8, "rgba(16,185,129,0.2)");
    gradient.addColorStop(1, "rgba(0,0,0,0)");
    ctx.fillStyle = gradient;
    ctx.fillRect(0, 0, 32, 32);

    const texture = new THREE.CanvasTexture(canvasTexture);

    const pMaterial = new THREE.PointsMaterial({
      size: 6,
      map: texture,
      vertexColors: true,
      transparent: true,
      opacity: 0.85,
      blending: THREE.AdditiveBlending,
      depthWrite: false
    });

    particleSystem = new THREE.Points(geometry, pMaterial);
    scene.add(particleSystem);

    // 5. Central 3D Geometric Floating Core
    const coreGroup = new THREE.Group();

    // Outer wireframe icosahedron
    const icoGeometry = new THREE.IcosahedronGeometry(130, 2);
    const icoMaterial = new THREE.MeshStandardMaterial({
      color: 0x93ab88,
      wireframe: true,
      transparent: true,
      opacity: 0.35,
      emissive: 0x10b981,
      emissiveIntensity: 0.2
    });
    geometryMesh = new THREE.Mesh(icoGeometry, icoMaterial);
    coreGroup.add(geometryMesh);

    // Inner glowing sphere
    const sphereGeo = new THREE.SphereGeometry(65, 32, 32);
    const sphereMat = new THREE.MeshStandardMaterial({
      color: 0x10b981,
      roughness: 0.2,
      metalness: 0.8,
      wireframe: false,
      transparent: true,
      opacity: 0.65,
      emissive: 0x059669,
      emissiveIntensity: 0.4
    });
    innerCore = new THREE.Mesh(sphereGeo, sphereMat);
    coreGroup.add(innerCore);

    // Orbital ring
    const ringGeo = new THREE.TorusGeometry(180, 2, 16, 100);
    const ringMat = new THREE.MeshBasicMaterial({
      color: 0x38bdf8,
      transparent: true,
      opacity: 0.45,
      wireframe: true
    });
    ringMesh = new THREE.Mesh(ringGeo, ringMat);
    ringMesh.rotation.x = Math.PI / 3;
    coreGroup.add(ringMesh);

    coreGroup.position.set(220, 30, -50);
    scene.add(coreGroup);

    // 6. Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    scene.add(ambientLight);

    const pointLight1 = new THREE.PointLight(0x10b981, 2, 800);
    pointLight1.position.set(200, 200, 300);
    scene.add(pointLight1);

    const pointLight2 = new THREE.PointLight(0x38bdf8, 2, 800);
    pointLight2.position.set(-200, -200, 200);
    scene.add(pointLight2);

    // Event Listeners
    window.addEventListener("resize", onWindowResize);
    document.addEventListener("mousemove", onDocumentMouseMove);
    window.addEventListener("scroll", onScroll);
    document.addEventListener("click", onDocumentClick);

    // Start animation loop
    animate();
  }

  function onWindowResize() {
    windowHalfX = window.innerWidth / 2;
    windowHalfY = window.innerHeight / 2;

    camera.aspect = window.innerWidth / window.innerHeight;
    camera.updateProjectionMatrix();

    renderer.setSize(window.innerWidth, window.innerHeight);
  }

  function onDocumentMouseMove(event) {
    mouseX = (event.clientX - windowHalfX) * 0.4;
    mouseY = (event.clientY - windowHalfY) * 0.4;
  }

  function onScroll() {
    scrollY = window.pageYOffset || document.documentElement.scrollTop;
  }

  function onDocumentClick(e) {
    if (!particleSystem) return;
    // Interactive pulse effect on click
    const positions = particleSystem.geometry.attributes.position.array;
    for (let i = 0; i < positions.length; i += 9) {
      positions[i] += (Math.random() - 0.5) * 15;
      positions[i + 1] += (Math.random() - 0.5) * 15;
      positions[i + 2] += (Math.random() - 0.5) * 15;
    }
    particleSystem.geometry.attributes.position.needsUpdate = true;
  }

  function animate() {
    requestAnimationFrame(animate);

    const time = Date.now() * 0.001;

    // Smooth mouse lerp
    targetX += (mouseX - targetX) * 0.05;
    targetY += (mouseY - targetY) * 0.05;

    // Camera dynamic perspective based on mouse + scroll
    camera.position.x = targetX * 0.8;
    camera.position.y = -targetY * 0.8 + Math.sin(time * 0.5) * 10;
    camera.lookAt(scene.position);

    // Rotate particles
    if (particleSystem) {
      particleSystem.rotation.y = time * 0.04;
      particleSystem.rotation.x = time * 0.02;
    }

    // Animate central 3D core
    if (geometryMesh) {
      geometryMesh.rotation.x = time * 0.25;
      geometryMesh.rotation.y = time * 0.35;
      geometryMesh.position.y = Math.sin(time * 1.5) * 15;
    }

    if (innerCore) {
      const scale = 1 + Math.sin(time * 3) * 0.08;
      innerCore.scale.set(scale, scale, scale);
      innerCore.rotation.y = -time * 0.4;
    }

    if (ringMesh) {
      ringMesh.rotation.z = time * 0.3;
      ringMesh.rotation.y = time * 0.2;
    }

    // Reposition 3D core dynamically on mobile vs desktop
    if (window.innerWidth < 1024 && geometryMesh && geometryMesh.parent) {
      geometryMesh.parent.position.set(0, 80, -120);
      geometryMesh.parent.scale.set(0.7, 0.7, 0.7);
    } else if (geometryMesh && geometryMesh.parent) {
      geometryMesh.parent.position.set(220, 20, -50);
      geometryMesh.parent.scale.set(1, 1, 1);
    }

    renderer.render(scene, camera);
  }

  // Initialize on DOM ready
  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initThree);
  } else {
    initThree();
  }
})();
